﻿using System;
using System.Data.Common;
using System.Diagnostics;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Calculator : Form
    {
        double value;
        string soperator;
        bool check;
        public Calculator()
        {
            InitializeComponent();
        }

        private void PNumber(object sender, EventArgs e)
        {
            if ((soperator == "+") || (soperator == "-") || (soperator == "*") || (soperator == "/"))
            {
                if (check)
                {
                    check = false;
                    Result.Text = "0";
                }
            }

            Button b = sender as Button;
            if (Result.Text == "0")
                Result.Text = b.Text;
            else
            {
                Result.Text += b.Text;
            }
        }

        private void POperator(object sender, EventArgs e)
        {
            Button b = sender as Button;
            value = double.Parse(Result.Text);
            soperator = b.Text;
            Result.Text += b.Text;
            check = true;
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want To Exit?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }

            else
            {
                ActiveForm.Show();
            }
        }

        private void MyWebsiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Process.Start("https://feedbackadiprbu.wixsite.com/website");
        }

        private void CreatedInVisualStudioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://en.wikipedia.org/wiki/Microsoft_Visual_Studio");
        }

        private void WinformsCNETToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://en.wikipedia.org/wiki/Windows_Forms");
            Process.Start("https://en.wikipedia.org/wiki/.NET_Framework");
        }

        private void DesignedByAdityaSPrabhuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://feedbackadiprbu.wixsite.com/website/about");
        }

        private void DeleteApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            Result.Text = "0";
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            Result.Text = "0";
            value = 0;
        }

        private void Equal_Click(object sender, EventArgs e)
        {
            try
            {
                switch (soperator)
                {
                    case "+":
                        Result.Text = (value+double.Parse(Result.Text)).ToString();
                        break;

                    case "-":
                        Result.Text = (value - double.Parse(Result.Text)).ToString();
                        break;

                    case "*":
                        Result.Text = (value * double.Parse(Result.Text)).ToString();
                        break;

                    case "/":
                        Result.Text = (value / double.Parse(Result.Text)).ToString();
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

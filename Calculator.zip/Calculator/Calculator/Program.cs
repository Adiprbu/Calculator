﻿using System;
using System.Windows.Forms;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using System.Globalization;
using System.Collections.Generic;

namespace Calculator
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        private static async System.Threading.Tasks.Task Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            AppCenter.Start("ec782ab9-d13f-434d-800c-f3f1a6a24b61",
                   typeof(Analytics), typeof(Crashes));

            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.ThrowException);
            AppCenter.Start();

            Application.ThreadException += (sender, args) =>
            {
                Crashes.TrackError(args.Exception);
            };
            AppCenter.Start();

            bool didAppCrash = await Crashes.HasCrashedInLastSessionAsync();

            ErrorReport crashReport = await Crashes.GetLastSessionCrashReportAsync();

            Crashes.ShouldProcessErrorReport = (ErrorReport report) =>
            {
                // Check the report in here and return true or false depending on the ErrorReport.
                return true;
            };

            // Depending on the user's choice, call Crashes.NotifyUserConfirmation() with the right value.
            Crashes.NotifyUserConfirmation(UserConfirmation.DontSend);
            Crashes.NotifyUserConfirmation(UserConfirmation.Send);
            Crashes.NotifyUserConfirmation(UserConfirmation.AlwaysSend);

            try
            {
                // your code goes here.
            }
            catch (Exception exception)
            {
                var properties = new Dictionary<string, string>
    {
        { "Category", "Music" },
        { "Wifi", "On"}
    };
                Crashes.TrackError(exception, properties);
            }

            Application.Run(new Calculator());
        }

        private static void SetCountryCode()
        {
            // This fallback country code doesn't reflect the physical device location, but rather the
            // country that corresponds to the culture it uses.
            var countryCode = RegionInfo.CurrentRegion.TwoLetterISORegionName;
            AppCenter.SetCountryCode(countryCode);
        }


    }
}
